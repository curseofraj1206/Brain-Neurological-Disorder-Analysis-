/* ── Hamburger / mobile-nav toggle ───────────────────────────────── */
(function () {
  'use strict';

  const btn = document.getElementById('hamburger-btn');
  const nav = document.getElementById('mobile-nav');
  if (!btn || !nav) return;

  function openMenu() {
    btn.classList.add('open');
    btn.setAttribute('aria-expanded', 'true');
    nav.style.display = 'flex';
    nav.removeAttribute('aria-hidden');
  }

  function closeMenu() {
    btn.classList.remove('open');
    btn.setAttribute('aria-expanded', 'false');
    nav.style.display = 'none';
    nav.setAttribute('aria-hidden', 'true');
  }

  btn.addEventListener('click', function () {
    if (btn.classList.contains('open')) {
      closeMenu();
    } else {
      openMenu();
    }
  });

  /* Close when a nav link is clicked */
  nav.querySelectorAll('a').forEach(function (link) {
    link.addEventListener('click', closeMenu);
  });

  /* Close when clicking outside */
  document.addEventListener('click', function (e) {
    if (!btn.contains(e.target) && !nav.contains(e.target)) {
      closeMenu();
    }
  });

  /* Close on Escape key */
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeMenu();
  });
}());
