/**
 * live_monitor.js
 * Real-time EEG waveform graph + disease prediction panel.
 * Connects to the Flask SSE endpoint /api/live/stream via EventSource.
 */

(function () {
  'use strict';

  /* ── Constants ─────────────────────────────────────────────────── */
  const EEG_CHANNELS = [
    'Fp1','Fp2','F3','F4','C3','C4','P3','P4',
    'O1','O2','F7','F8','T7','T8','P7','P8','Fz','Cz','Pz',
  ];

  const CHANNEL_COLORS = [
    '#19e4ff','#e73bff','#38ef7d','#ffb24a','#1687ff','#ff6b7a',
    '#a0f0ff','#d38fff','#7dffd0','#ffe8a0','#80c3ff','#ffa0ab',
    '#00c8e0','#cc00e0','#22cc60','#e09000','#0060d0','#d04050',
    '#66ccff',
  ];

  const WINDOW_SECS   = 10;   // rolling x-axis window in seconds
  const FRAME_RATE_HZ = 4;    // expected frames per second (250 ms per frame)
  const MAX_POINTS    = WINDOW_SECS * FRAME_RATE_HZ;

  /* ── State ─────────────────────────────────────────────────────── */
  let eventSource   = null;
  let chart         = null;
  let frameCount    = 0;
  let sessionBuffer = [];   // [{ts, channels}]
  let activeChannels = new Set(EEG_CHANNELS.slice(0, 4));  // default 4 visible

  /* ── DOM refs ──────────────────────────────────────────────────── */
  const statusDot     = document.getElementById('status-dot');
  const statusText    = document.getElementById('status-text');
  const statusBadge   = document.getElementById('status-badge');
  const connectBtn    = document.getElementById('connect-btn');
  const scanBtn       = document.getElementById('scan-btn');
  const portSelect    = document.getElementById('port-select');
  const baudSelect    = document.getElementById('baud-select');
  const exportBtn     = document.getElementById('export-btn');
  const saveBtn       = document.getElementById('save-btn');
  const waveMeta      = document.getElementById('wave-meta');
  const frameCountEl  = document.getElementById('frame-count');
  const channelGrid   = document.getElementById('channel-grid');
  const legendEl      = document.getElementById('channel-legend');
  const btnSimulate   = document.getElementById('btn-simulate');
  const btnSerial     = document.getElementById('btn-serial');
  const serialOptions = document.getElementById('serial-options');
  const verdictBadge  = document.getElementById('verdict-badge');
  const verdictLabel  = document.getElementById('verdict-label');
  const confPct       = document.getElementById('conf-pct');
  const confFill      = document.getElementById('conf-fill');

  /* ── Mode toggle ────────────────────────────────────────────────── */
  let currentMode = 'simulate';

  [btnSimulate, btnSerial].forEach(function (btn) {
    btn.addEventListener('click', function () {
      currentMode = btn.dataset.mode;
      btnSimulate.classList.toggle('active', currentMode === 'simulate');
      btnSerial.classList.toggle('active', currentMode === 'serial');
      serialOptions.classList.toggle('hidden', currentMode === 'simulate');
    });
  });

  /* ── Channel checkboxes ─────────────────────────────────────────── */
  EEG_CHANNELS.forEach(function (ch, i) {
    const label = document.createElement('label');
    label.className = 'ch-check';
    label.title = ch;

    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.id   = 'ch-' + ch;
    cb.value = ch;
    cb.checked = activeChannels.has(ch);
    cb.addEventListener('change', function () {
      if (this.checked) activeChannels.add(ch);
      else activeChannels.delete(ch);
      rebuildChart();
    });

    const dot = document.createElement('span');
    dot.style.cssText =
      'width:8px;height:8px;border-radius:50%;background:' + CHANNEL_COLORS[i] +
      ';flex-shrink:0;display:inline-block;';

    label.appendChild(cb);
    label.appendChild(dot);
    label.appendChild(document.createTextNode(ch));
    channelGrid.appendChild(label);
  });

  /* ── Gradient SVG def for ring ──────────────────────────────────── */
  (function injectSvgGradient() {
    const svg = document.querySelector('.conf-ring');
    const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
    defs.innerHTML =
      '<linearGradient id="ringGrad" x1="0%" y1="0%" x2="100%" y2="0%">' +
      '<stop offset="0%"   stop-color="#19e4ff"/>' +
      '<stop offset="50%"  stop-color="#1687ff"/>' +
      '<stop offset="100%" stop-color="#e73bff"/>' +
      '</linearGradient>';
    svg.prepend(defs);
  }());

  /* ── Chart.js setup ─────────────────────────────────────────────── */
  function buildDatasets() {
    return Array.from(activeChannels).map(function (ch) {
      const colorIdx = EEG_CHANNELS.indexOf(ch);
      const color = CHANNEL_COLORS[colorIdx] || '#ffffff';
      return {
        label: ch,
        data: [],
        borderColor: color,
        backgroundColor: 'transparent',
        borderWidth: 1.5,
        pointRadius: 0,
        tension: 0.3,
      };
    });
  }

  function buildChart() {
    const ctx = document.getElementById('eeg-chart').getContext('2d');
    chart = new Chart(ctx, {
      type: 'line',
      data: { labels: [], datasets: buildDatasets() },
      options: {
        animation: false,
        responsive: true,
        maintainAspectRatio: false,
        interaction: { intersect: false, mode: 'index' },
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: 'rgba(3,7,22,0.92)',
            borderColor: 'rgba(99,213,255,0.3)',
            borderWidth: 1,
            titleColor: '#19e4ff',
            bodyColor: '#a8b8d8',
            callbacks: {
              label: function (ctx) {
                return ' ' + ctx.dataset.label + ': ' + ctx.parsed.y.toFixed(1) + ' µV';
              },
            },
          },
        },
        scales: {
          x: {
            ticks: { color: '#a8b8d8', font: { size: 10 }, maxTicksLimit: 8 },
            grid:  { color: 'rgba(99,213,255,0.06)' },
          },
          y: {
            ticks: { color: '#a8b8d8', font: { size: 10 } },
            grid:  { color: 'rgba(99,213,255,0.08)' },
            title: { display: true, text: 'µV', color: '#a8b8d8', font: { size: 11 } },
          },
        },
      },
    });
  }

  function rebuildChart() {
    if (chart) {
      chart.destroy();
      chart = null;
    }
    buildChart();
    rebuildLegend();
    // Re-feed stored buffer into the new chart
    sessionBuffer.slice(-MAX_POINTS).forEach(function (frame) {
      pushChannelData(frame.ts, frame.channels, false);
    });
    if (chart) chart.update('none');
  }

  function rebuildLegend() {
    legendEl.innerHTML = '';
    Array.from(activeChannels).forEach(function (ch) {
      const colorIdx = EEG_CHANNELS.indexOf(ch);
      const color = CHANNEL_COLORS[colorIdx] || '#fff';
      const item = document.createElement('div');
      item.className = 'legend-item';
      item.innerHTML =
        '<span class="legend-dot" style="background:' + color + '"></span>' + ch;
      legendEl.appendChild(item);
    });
  }

  function pushChannelData(ts, channels, doUpdate) {
    if (!chart) return;
    const label = new Date(ts * 1000).toLocaleTimeString('en', { hour12: false });

    chart.data.labels.push(label);
    if (chart.data.labels.length > MAX_POINTS) {
      chart.data.labels.shift();
    }

    chart.data.datasets.forEach(function (ds) {
      const val = channels[ds.label] || 0;
      ds.data.push(val);
      if (ds.data.length > MAX_POINTS) ds.data.shift();
    });

    if (doUpdate) chart.update('none');
  }

  /* ── Status helpers ─────────────────────────────────────────────── */
  function setStatus(state, label) {
    statusDot.className = 'status-dot ' + state;
    statusText.textContent = label;
  }

  /* ── Prediction UI ──────────────────────────────────────────────── */
  const CIRCUMFERENCE = 2 * Math.PI * 50;   // r = 50

  function updatePredictionUI(pred) {
    if (!pred || pred.error) return;

    const name = pred.prediction || '';
    const conf = (pred.confidence || 0) * 100;

    // Verdict badge
    verdictLabel.textContent = name;
    verdictBadge.className = 'verdict-badge';
    if (name.toLowerCase().includes('alzheimer')) verdictBadge.classList.add('alzheimers');
    else if (name.toLowerCase().includes('epilepsy')) verdictBadge.classList.add('epilepsy');
    else if (name.toLowerCase().includes('schizophrenia')) verdictBadge.classList.add('schizophrenia');

    // Confidence ring
    confPct.textContent = conf.toFixed(0) + '%';
    const filled = (conf / 100) * CIRCUMFERENCE;
    confFill.setAttribute('stroke-dasharray', filled.toFixed(1) + ' ' + CIRCUMFERENCE.toFixed(1));

    // Score bars
    const scores = pred.scores || {};
    const keyMap = {
      'Alzheimers': 'Alzheimers',
      'Alzheimer\'s': 'Alzheimers',
      'Epilepsy': 'Epilepsy',
      'Schizophrenia': 'Schizophrenia',
    };

    Object.entries(scores).forEach(function ([rawKey, val]) {
      const key = keyMap[rawKey] || rawKey;
      const pctEl  = document.getElementById('pct-' + key);
      const fillEl = document.getElementById('fill-' + key);
      if (pctEl)  pctEl.textContent  = (val * 100).toFixed(1) + '%';
      if (fillEl) fillEl.style.width = (val * 100).toFixed(1) + '%';
    });
  }

  /* ── Port scanning ──────────────────────────────────────────────── */
  function scanPorts() {
    scanBtn.textContent = '…';
    fetch(window.LIVE_PORTS_URL)
      .then(function (r) { return r.json(); })
      .then(function (ports) {
        portSelect.innerHTML = '<option value="">— select port —</option>';
        ports.forEach(function (p) {
          const opt = document.createElement('option');
          opt.value = p.port;
          opt.textContent = p.port + (p.description ? '  (' + p.description + ')' : '');
          portSelect.appendChild(opt);
        });
        if (ports.length === 0) {
          portSelect.innerHTML = '<option value="">No ports found</option>';
        }
      })
      .catch(function () {
        portSelect.innerHTML = '<option value="">Error scanning ports</option>';
      })
      .finally(function () { scanBtn.textContent = '⟳'; });
  }

  scanBtn.addEventListener('click', scanPorts);

  /* ── Connect / Disconnect ───────────────────────────────────────── */
  function connect() {
    if (eventSource) {
      disconnect();
      return;
    }

    // Build URL
    let url = window.LIVE_STREAM_URL;
    if (currentMode === 'simulate') {
      url += '?port=simulate';
    } else {
      const port = portSelect.value.trim();
      if (!port) {
        alert('Please select a serial port first.');
        return;
      }
      const baud = baudSelect.value;
      url += '?port=' + encodeURIComponent(port) + '&baud=' + baud;
    }

    setStatus(currentMode === 'simulate' ? 'simulating' : 'connected',
              currentMode === 'simulate' ? 'Simulating' : 'Connected');
    connectBtn.textContent = 'Disconnect';
    exportBtn.disabled = false;
    saveBtn.disabled = false;
    waveMeta.textContent = 'Receiving data…';
    sessionBuffer = [];
    frameCount = 0;
    frameCountEl.textContent = '0';

    if (!chart) buildChart();
    rebuildLegend();

    eventSource = new EventSource(url);

    eventSource.onmessage = function (e) {
      let frame;
      try { frame = JSON.parse(e.data); } catch (_) { return; }
      if (frame.error) {
        setStatus('error', 'Error');
        waveMeta.textContent = 'Stream error: ' + frame.error;
        return;
      }

      frameCount++;
      frameCountEl.textContent = frameCount;

      // Buffer for CSV export
      sessionBuffer.push({ ts: frame.ts, channels: frame.channels });
      if (sessionBuffer.length > MAX_POINTS * 6) sessionBuffer.shift();

      pushChannelData(frame.ts, frame.channels, true);

      if (frame.prediction) {
        updatePredictionUI(frame.prediction);
      }

      const d = new Date(frame.ts * 1000);
      waveMeta.textContent = d.toLocaleTimeString() + '  ·  ' + frameCount + ' frames';
    };

    eventSource.onerror = function () {
      setStatus('error', 'Connection lost');
      connectBtn.textContent = 'Reconnect';
      if (eventSource) { eventSource.close(); eventSource = null; }
    };
  }

  function disconnect() {
    if (eventSource) { eventSource.close(); eventSource = null; }
    setStatus('', 'Disconnected');
    connectBtn.textContent = 'Connect';
    waveMeta.textContent = '— stopped —';
  }

  connectBtn.addEventListener('click', connect);

  /* ── Export CSV ─────────────────────────────────────────────────── */
  exportBtn.addEventListener('click', function () {
    if (!sessionBuffer.length) return;
    const cols = ['timestamp'].concat(EEG_CHANNELS);
    const rows = [cols.join(',')];
    sessionBuffer.forEach(function (frame) {
      const row = [frame.ts].concat(EEG_CHANNELS.map(function (ch) {
        return (frame.channels[ch] || 0).toFixed(4);
      }));
      rows.push(row.join(','));
    });
    const blob = new Blob([rows.join('\n')], { type: 'text/csv' });
    const a    = document.createElement('a');
    a.href     = URL.createObjectURL(blob);
    a.download = 'eeg_session_' + Date.now() + '.csv';
    a.click();
    URL.revokeObjectURL(a.href);
  });

  /* ── Save to Dashboard ──────────────────────────────────────────── */
  saveBtn.addEventListener('click', function () {
    // Build a minimal CSV from the session buffer and POST to /predict
    if (!sessionBuffer.length) return;
    const cols = EEG_CHANNELS;
    const lines = [cols.join(',')];
    sessionBuffer.slice(-500).forEach(function (frame) {
      lines.push(cols.map(function (ch) {
        return (frame.channels[ch] || 0).toFixed(4);
      }).join(','));
    });
    const blob = new Blob([lines.join('\n')], { type: 'text/csv' });
    const patientName = document.getElementById('session-patient').value || 'Live Session';

    const fd = new FormData();
    fd.append('csv_file', blob, 'live_session.csv');
    fd.append('patient_name', patientName);

    saveBtn.textContent = 'Saving…';
    saveBtn.disabled = true;

    fetch(window.LIVE_PREDICT_URL, { method: 'POST', body: fd })
      .then(function (r) {
        if (r.ok) {
          saveBtn.textContent = '✓ Saved';
          setTimeout(function () {
            saveBtn.textContent = 'Save to Dashboard';
            saveBtn.disabled = false;
          }, 2500);
        } else {
          throw new Error('Save failed');
        }
      })
      .catch(function () {
        saveBtn.textContent = 'Save failed';
        saveBtn.disabled = false;
      });
  });

  /* ── Init ───────────────────────────────────────────────────────── */
  buildChart();
  rebuildLegend();
  setStatus('', 'Disconnected');

}());
