from pathlib import Path

import joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

from preprocessing.data_cleaning import PROCESSED_DIR, save_clean_dataset
from preprocessing.feature_extraction import extract_features
from preprocessing.normalization import fit_transform, transform


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SAVED_MODELS = PROJECT_ROOT / "saved_models"


def create_splits(max_rows_per_file: int | None = None, test_size: float = 0.15, val_size: float = 0.15):
    clean_path = save_clean_dataset(max_rows_per_file=max_rows_per_file)
    clean = pd.read_csv(clean_path)
    data = extract_features(clean)

    feature_cols = [column for column in data.columns if column != "label"]
    encoder = LabelEncoder()
    data["target"] = encoder.fit_transform(data["label"])
    data = data.drop(columns=["label"])

    train_val, test = train_test_split(
        data,
        test_size=test_size,
        random_state=42,
        stratify=data["target"],
    )
    relative_val = val_size / (1.0 - test_size)
    train, val = train_test_split(
        train_val,
        test_size=relative_val,
        random_state=42,
        stratify=train_val["target"],
    )

    train, scaler = fit_transform(train, feature_cols, SAVED_MODELS / "scaler.pkl")
    val = transform(val, feature_cols, scaler)
    test = transform(test, feature_cols, scaler)

    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    train.to_csv(PROCESSED_DIR / "train.csv", index=False)
    val.to_csv(PROCESSED_DIR / "val.csv", index=False)
    test.to_csv(PROCESSED_DIR / "test.csv", index=False)

    metadata = {
        "feature_columns": feature_cols,
        "classes": encoder.classes_.tolist(),
    }
    joblib.dump(encoder, SAVED_MODELS / "label_encoder.pkl")
    joblib.dump(metadata, SAVED_MODELS / "metadata.pkl")
    return train, val, test, metadata


if __name__ == "__main__":
    create_splits()
    print("Saved train/val/test splits.")
