"""
Feature extraction for EEG brain-disorder classification.

Produces ~55 discriminative features per sample:
  - Raw channel values (19 features)
  - Global signal statistics: mean, std, min, max, range, energy,
    skewness, kurtosis, coefficient of variation (9 features)
  - Region means: frontal, central, parietal, occipital (4 features)
  - Hemisphere means & asymmetry: left, right, asymmetry (3 features)
  - Region std: frontal_std, central_std, parietal_std, occipital_std (4 features)
  - Region energy (mean square): frontal_energy, central_energy,
    parietal_energy, occipital_energy (4 features)
  - Zero-crossing rate (cheap alpha/beta/theta band-power proxy) (1 feature)
  - Cross-channel correlations: Fp1-Fp2, C3-C4, O1-O2, F3-F4,
    T7-T8, P3-P4, F7-F8 (7 features)
  - Peak-to-peak per region: frontal, central, parietal, occipital (4 features)

Total: 19 + 9 + 4 + 3 + 4 + 4 + 1 + 7 + 4 = 55 features
"""
import warnings

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats

from preprocessing.data_cleaning import EEG_CHANNELS

# ── Region definitions ──────────────────────────────────────────────────────

FRONTAL   = ["Fp1", "Fp2", "F3", "F4", "F7", "F8", "Fz"]
CENTRAL   = ["C3", "C4", "Cz"]
PARIETAL  = ["P3", "P4", "P7", "P8", "Pz"]
OCCIPITAL = ["O1", "O2"]
TEMPORAL  = ["T7", "T8"]
LEFT      = ["Fp1", "F3", "C3", "P3", "O1", "F7", "T7", "P7"]
RIGHT     = ["Fp2", "F4", "C4", "P4", "O2", "F8", "T8", "P8"]

# Cross-channel pairs for correlation features
CORR_PAIRS = [
    ("Fp1", "Fp2"),
    ("C3",  "C4"),
    ("O1",  "O2"),
    ("F3",  "F4"),
    ("T7",  "T8"),
    ("P3",  "P4"),
    ("F7",  "F8"),
]


def _safe_zcr(arr: np.ndarray) -> float:
    """Zero-crossing rate across columns (proxy for frequency content)."""
    if arr.shape[1] < 2:
        return 0.0
    signs = np.sign(arr - arr.mean(axis=1, keepdims=True))
    crossings = np.diff(signs, axis=1)
    return float(np.mean(np.abs(crossings) > 0))


def _cross_corr(ch_a: np.ndarray, ch_b: np.ndarray) -> np.ndarray:
    """Per-row Pearson-style correlation (fast, no NaN guard)."""
    a = ch_a - ch_a.mean(axis=1, keepdims=True)
    b = ch_b - ch_b.mean(axis=1, keepdims=True)
    num = (a * b).mean(axis=1)
    denom = np.sqrt((a ** 2).mean(axis=1) * (b ** 2).mean(axis=1)) + 1e-8
    return num / denom


def extract_features(df: pd.DataFrame) -> pd.DataFrame:
    channels = df[EEG_CHANNELS].astype(float)
    features = channels.copy()
    values = channels.to_numpy()  # shape (N, 19)

    # ── Global statistics ────────────────────────────────────────────────────
    features["signal_mean"]  = values.mean(axis=1)
    features["signal_std"]   = values.std(axis=1)
    features["signal_min"]   = values.min(axis=1)
    features["signal_max"]   = values.max(axis=1)
    features["signal_range"] = features["signal_max"] - features["signal_min"]
    features["signal_energy"] = (values ** 2).mean(axis=1)

    # Skewness / kurtosis – suppress precision-loss warning on flat rows
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        skew_vals = scipy_stats.skew(values, axis=1)
        kurt_vals = scipy_stats.kurtosis(values, axis=1)
    # Replace NaN with 0 (flat row → no skew/excess kurtosis)
    features["signal_skew"] = np.nan_to_num(skew_vals, nan=0.0, posinf=0.0, neginf=0.0)
    features["signal_kurt"] = np.nan_to_num(kurt_vals, nan=0.0, posinf=0.0, neginf=0.0)

    # Coefficient of variation (handles near-zero std safely)
    mean_abs = np.abs(features["signal_mean"].to_numpy()) + 1e-8
    features["signal_cv"]   = features["signal_std"].to_numpy() / mean_abs

    # ── Region means ─────────────────────────────────────────────────────────
    features["frontal_mean"]   = channels[FRONTAL].mean(axis=1)
    features["central_mean"]   = channels[CENTRAL].mean(axis=1)
    features["parietal_mean"]  = channels[PARIETAL].mean(axis=1)
    features["occipital_mean"] = channels[OCCIPITAL].mean(axis=1)

    # ── Hemisphere & asymmetry ───────────────────────────────────────────────
    features["left_mean"]  = channels[LEFT].mean(axis=1)
    features["right_mean"] = channels[RIGHT].mean(axis=1)
    features["asymmetry"]  = features["left_mean"] - features["right_mean"]

    # ── Region standard deviations ───────────────────────────────────────────
    features["frontal_std"]   = channels[FRONTAL].std(axis=1)
    features["central_std"]   = channels[CENTRAL].std(axis=1)
    features["parietal_std"]  = channels[PARIETAL].std(axis=1)
    features["occipital_std"] = channels[OCCIPITAL].std(axis=1)

    # ── Region energy (mean of squares) ─────────────────────────────────────
    features["frontal_energy"]   = (channels[FRONTAL] ** 2).mean(axis=1)
    features["central_energy"]   = (channels[CENTRAL] ** 2).mean(axis=1)
    features["parietal_energy"]  = (channels[PARIETAL] ** 2).mean(axis=1)
    features["occipital_energy"] = (channels[OCCIPITAL] ** 2).mean(axis=1)

    # ── Zero-crossing rate (band-power proxy) ────────────────────────────────
    # Computed per sample across the 19 channel values
    centered = values - values.mean(axis=1, keepdims=True)
    signs = np.sign(centered)
    # Count sign changes across the 19 channels
    zcr = (np.diff(signs, axis=1) != 0).mean(axis=1)
    features["zero_crossing_rate"] = zcr

    # ── Cross-channel correlations ────────────────────────────────────────────
    for ch_a, ch_b in CORR_PAIRS:
        a = channels[[ch_a]].to_numpy()  # (N,1)
        b = channels[[ch_b]].to_numpy()
        # broadcast subtraction
        a_c = a - a.mean()
        b_c = b - b.mean()
        corr = (a_c * b_c).mean(axis=0) / (
            (np.sqrt((a_c ** 2).mean()) * np.sqrt((b_c ** 2).mean())) + 1e-8
        )
        # corr is a scalar here; use per-sample version
        a_vals = channels[ch_a].to_numpy().reshape(-1, 1)
        b_vals = channels[ch_b].to_numpy().reshape(-1, 1)
        corr_per_row = _cross_corr(a_vals, b_vals)
        features[f"corr_{ch_a}_{ch_b}"] = corr_per_row

    # ── Peak-to-peak per region ───────────────────────────────────────────────
    features["frontal_p2p"]   = channels[FRONTAL].max(axis=1) - channels[FRONTAL].min(axis=1)
    features["central_p2p"]   = channels[CENTRAL].max(axis=1) - channels[CENTRAL].min(axis=1)
    features["parietal_p2p"]  = channels[PARIETAL].max(axis=1) - channels[PARIETAL].min(axis=1)
    features["occipital_p2p"] = channels[OCCIPITAL].max(axis=1) - channels[OCCIPITAL].min(axis=1)

    if "label" in df.columns:
        features["label"] = df["label"].values

    return features


def feature_columns() -> list[str]:
    """Return a list of all feature column names (excluding 'label')."""
    sample = pd.DataFrame([{ch: 0.0 for ch in EEG_CHANNELS}])
    return [col for col in extract_features(sample).columns if col != "label"]
