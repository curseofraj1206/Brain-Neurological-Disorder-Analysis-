from pathlib import Path

import joblib
import pandas as pd
from sklearn.preprocessing import StandardScaler


def fit_transform(train: pd.DataFrame, feature_cols: list[str], save_path: Path):
    scaler = StandardScaler()
    train_scaled = train.copy()
    train_scaled[feature_cols] = scaler.fit_transform(train[feature_cols])
    save_path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(scaler, save_path)
    return train_scaled, scaler


def transform(data: pd.DataFrame, feature_cols: list[str], scaler: StandardScaler) -> pd.DataFrame:
    scaled = data.copy()
    scaled[feature_cols] = scaler.transform(data[feature_cols])
    return scaled
