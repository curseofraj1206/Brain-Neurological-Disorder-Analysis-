from pathlib import Path
import re

import numpy as np
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = PROJECT_ROOT / "datasets" / "raw"
PROCESSED_DIR = PROJECT_ROOT / "datasets" / "processed"

# Maximum rows read during prediction (training always reads everything)
PREDICT_SAMPLE_SIZE = 5000

EEG_CHANNELS = [
    "Fp1", "Fp2", "F3", "F4", "C3", "C4", "P3", "P4", "O1", "O2",
    "F7", "F8", "T7", "T8", "P7", "P8", "Fz", "Cz", "Pz",
]

ALIASES = {
    "T3": "T7",
    "T4": "T8",
    "T5": "P7",
    "T6": "P8",
}

CHANNEL_LOOKUP = {channel.lower(): channel for channel in EEG_CHANNELS}
CHANNEL_LOOKUP.update({old.lower(): new for old, new in ALIASES.items()})
CSV_DELIMITERS = (None, ",", ";", "\t", "|")


def _normalize_column_name(name: object) -> str:
    normalized = re.sub(r"[^a-z0-9]+", "", str(name).lower())
    normalized = normalized.replace("eeg", "")
    normalized = normalized.replace("channel", "")
    return normalized


def _channel_from_column(name: object) -> str | None:
    col_str = str(name).lower().strip()
    
    # Normalize by replacing eeg and channel
    normalized = col_str.replace("eeg", "").replace("channel", "").strip()
    normalized_clean = re.sub(r"^[^a-z0-9]+|[^a-z0-9]+$", "", normalized)
    
    if normalized_clean in CHANNEL_LOOKUP:
        return CHANNEL_LOOKUP[normalized_clean]
        
    # Split by non-alphanumeric to check words
    normalized_spaced = re.sub(r"[^a-z0-9]+", " ", normalized)
    words = normalized_spaced.split()
    for word in words:
        if word in CHANNEL_LOOKUP:
            return CHANNEL_LOOKUP[word]
            
    # Fallback to regex check on clean alphanumeric string
    normalized_alphanum = re.sub(r"[^a-z0-9]+", "", normalized)
    sorted_keys = sorted(CHANNEL_LOOKUP.keys(), key=len, reverse=True)
    for key in sorted_keys:
        if key == "fz":
            pattern = re.compile(r"(?<!p)fz(?![a-z0-9])")
        elif key == "pz":
            pattern = re.compile(r"(?<!f)pz(?![a-z0-9])")
        elif key.endswith(('z', 'x', 'y')):
            pattern = re.compile(rf"{key}(?![a-z0-9])")
        else:
            pattern = re.compile(rf"{key}(?!\d)")
            
        if pattern.search(normalized_alphanum):
            return CHANNEL_LOOKUP[key]
            
    return None


def _rewind_csv_file(csv_file: object) -> None:
    stream = getattr(csv_file, "stream", csv_file)
    seek = getattr(stream, "seek", None)
    if callable(seek):
        seek(0)


def _looks_like_eeg_csv(df: pd.DataFrame) -> bool:
    if any(_channel_from_column(column) for column in df.columns):
        return True

    numeric = df.apply(pd.to_numeric, errors="coerce").dropna(axis=1, how="all")
    return numeric.shape[1] >= len(EEG_CHANNELS)


def read_signal_csv(csv_file, max_rows: int | None = None) -> pd.DataFrame:
    """Read an EEG signal CSV file.

    Parameters
    ----------
    csv_file:
        File path or file-like object.
    max_rows:
        Maximum number of rows to read.  ``None`` (default) reads the entire
        file with no row limit.
    """
    if max_rows is not None and max_rows < 1:
        raise ValueError("max_rows must be at least 1 when specified.")
    best_frame = None
    last_error = None

    for delimiter in CSV_DELIMITERS:
        _rewind_csv_file(csv_file)
        read_kwargs: dict = {"index_col": False}
        if max_rows is not None:
            read_kwargs["nrows"] = max_rows
        if delimiter is None:
            read_kwargs.update({"sep": None, "engine": "python"})
        else:
            read_kwargs["sep"] = delimiter

        try:
            frame = pd.read_csv(csv_file, **read_kwargs)
        except (pd.errors.ParserError, UnicodeDecodeError, OSError, ValueError) as exc:
            last_error = exc
            continue

        if _looks_like_eeg_csv(frame):
            return frame
        if best_frame is None or frame.shape[1] > best_frame.shape[1]:
            best_frame = frame

    if best_frame is not None:
        return best_frame
    if last_error is not None:
        raise ValueError(f"Could not read CSV file: {last_error}") from last_error
    raise ValueError("Could not read CSV file.")


def fast_read_signal_csv(csv_file, sample_size: int = PREDICT_SAMPLE_SIZE) -> pd.DataFrame:
    """Read the first ``sample_size`` rows from an EEG CSV for fast prediction.

    EEG recordings are stationary — the statistical properties (mean, std,
    correlations) of the first 5,000 rows are virtually identical to those
    of any 5,000-row window anywhere in the file.  Reading only the head
    of the file with ``nrows`` is O(sample_size) and completes in < 1 s
    regardless of file size.

    The previous skiprows approach was O(total_rows) for building the list
    AND O(total_rows) inside pandas, making it extremely slow for large files.
    """
    return read_signal_csv(csv_file, max_rows=sample_size)


FILE_LABELS = {
    "alzheimers.csv": "Alzheimers",
    "epilepsy.csv": "Epilepsy",
    "schizophrenia.csv": "Schizophrenia",
}


def _standardize_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    renamed = {}
    for column in df.columns:
        channel = _channel_from_column(column)
        if channel and channel not in renamed.values():
            renamed[column] = channel
    df = df.rename(columns=renamed)

    matched_channels = [channel for channel in EEG_CHANNELS if channel in df.columns]
    if not matched_channels:
        numeric = df.apply(pd.to_numeric, errors="coerce")
        numeric = numeric.dropna(axis=1, how="all")
        if numeric.shape[1] >= len(EEG_CHANNELS):
            clean = numeric.iloc[:, :len(EEG_CHANNELS)].copy()
            clean.columns = EEG_CHANNELS
            clean = clean.dropna(how="all")
            return clean.fillna(clean.median(numeric_only=True)).fillna(0.0)

    for channel in EEG_CHANNELS:
        if channel not in df.columns:
            df[channel] = np.nan
    clean = df[EEG_CHANNELS].apply(pd.to_numeric, errors="coerce")
    clean = clean.dropna(how="all")
    clean = clean.fillna(clean.median(numeric_only=True)).fillna(0.0)
    return clean


def standardize_signal_columns(df: pd.DataFrame) -> pd.DataFrame:
    return _standardize_columns(df)


def load_raw_file(path: Path, label: str, max_rows: int | None = None) -> pd.DataFrame:
    """Load a raw EEG CSV and attach a disorder label.

    ``max_rows=None`` reads the entire file (default).
    """
    df = read_signal_csv(path, max_rows=max_rows)
    df = _standardize_columns(df)
    df["label"] = label
    return df


def build_clean_dataset(max_rows_per_file: int | None = None) -> pd.DataFrame:
    """Build the combined cleaned dataset from all raw files.

    ``max_rows_per_file=None`` (default) reads every row of each CSV.
    """
    frames = []
    for filename, label in FILE_LABELS.items():
        path = RAW_DIR / filename
        if not path.exists():
            raise FileNotFoundError(f"Missing raw dataset: {path}")
        df = load_raw_file(path, label, max_rows=max_rows_per_file)
        print(f"  Loaded {len(df):,} rows from {filename} ({label})")
        frames.append(df)

    data = pd.concat(frames, ignore_index=True)
    data = data.replace([np.inf, -np.inf], np.nan).dropna()
    data = data.sample(frac=1.0, random_state=42).reset_index(drop=True)
    print(f"  Total rows after cleaning: {len(data):,}")
    return data


def save_clean_dataset(max_rows_per_file: int | None = None) -> Path:
    """Save the combined cleaned dataset to disk.

    ``max_rows_per_file=None`` (default) reads every row of each CSV.
    """
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    data = build_clean_dataset(max_rows_per_file=max_rows_per_file)
    output = PROCESSED_DIR / "clean.csv"
    data.to_csv(output, index=False)
    return output


if __name__ == "__main__":
    path = save_clean_dataset()
    print(f"Saved clean dataset to {path}")
