#include <HTTPClient.h>
#include <WiFi.h>

const char* WIFI_SSID = "FS3";
const char* WIFI_PASSWORD = "1234567890";

// Use your computer's LAN IP, not 127.0.0.1. Example: http://192.168.66.226:5000/api/predict
const char* PREDICTION_URL = "http://192.168.66.226:5000/api/predict";

const unsigned long SAMPLE_INTERVAL_MS = 1000;

struct ChannelPin {
  const char* name;
  uint8_t pin;
};

// ESP32 ADC1 pins are safest while Wi-Fi is active. Replace these mappings with your EEG front-end outputs.
ChannelPin channels[] = {
  {"Fp1", 36},
  {"Fp2", 39},
  {"F3", 34},
  {"F4", 35},
  {"C3", 32},
  {"C4", 33}
};

const size_t CHANNEL_COUNT = sizeof(channels) / sizeof(channels[0]);

float readMicrovolts(uint8_t pin) {
  int raw = analogRead(pin);
  float voltage = (raw / 4095.0f) * 3.3f;
  return (voltage - 1.65f) * 1000000.0f;
}

String buildPayload() {
  String payload = "{\"signals\":{";
  for (size_t index = 0; index < CHANNEL_COUNT; index++) {
    if (index > 0) {
      payload += ",";
    }
    payload += "\"";
    payload += channels[index].name;
    payload += "\":";
    payload += String(readMicrovolts(channels[index].pin), 3);
  }
  payload += "}}";
  return payload;
}

void connectWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();
  Serial.print("ESP32 IP: ");
  Serial.println(WiFi.localIP());
}

void setup() {
  Serial.begin(115200);
  Serial.println("ESP32 code started");

  analogReadResolution(12);
  connectWiFi();
}
}

void loop() {
  String payload = buildPayload();
  Serial.println(payload);

  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(PREDICTION_URL);
    http.addHeader("Content-Type", "application/json");
    int status = http.POST(payload);
    String response = http.getString();
    http.end();

    Serial.print("HTTP ");
    Serial.print(status);
    Serial.print(": ");
    Serial.println(response);
  } else {
    connectWiFi();
  }

  delay(SAMPLE_INTERVAL_MS);
}
