# ESP32 Hardware Integration

This project keeps the machine-learning model on the computer/server. The ESP32 reads EEG front-end values and sends them to the Flask API at `/api/predict`. Flask uses the saved ensemble/XGBoost model by default because it performs better on this project's test split.

## Option 1: ESP32 Wi-Fi to Flask

1. Install the Arduino ESP32 board package.
2. Open `hardware/esp32_eeg_client/esp32_eeg_client.ino`.
3. Set:
   - `WIFI_SSID`
   - `WIFI_PASSWORD`
   - `PREDICTION_URL`
4. Start Flask so other devices on your network can reach it:

```powershell
python main.py serve --host 0.0.0.0 --port 5000
```

5. Upload the sketch and open the Arduino Serial Monitor at `115200` baud.

Use your computer's LAN IP in `PREDICTION_URL`, for example `http://192.168.66.226:5000/api/predict`. `127.0.0.1` points back to the ESP32 itself, so it will not reach Flask.

## Option 2: ESP32 USB Serial to Python

If you do not want the ESP32 to use Wi-Fi yet, send one JSON object per line over serial:

```json
{"signals":{"Fp1":10.2,"Fp2":8.1,"F3":2.0}}
```

Then run:

```powershell
python main.py esp32-serial --port COM5
```

The Python bridge predicts locally and writes one JSON result line back to the ESP32.

## Signal Notes

- ESP32 ADC pins expect `0` to `3.3V`; do not connect raw electrodes directly.
- Use an EEG analog front-end or isolation-safe acquisition board between the patient/electrodes and ESP32.
- The model supports these channels: `Fp1`, `Fp2`, `F3`, `F4`, `C3`, `C4`, `P3`, `P4`, `O1`, `O2`, `F7`, `F8`, `T7`, `T8`, `P7`, `P8`, `Fz`, `Cz`, `Pz`.
- Missing channels are filled with `0.0`, so start with the channels you can measure and add more as your hardware improves.
