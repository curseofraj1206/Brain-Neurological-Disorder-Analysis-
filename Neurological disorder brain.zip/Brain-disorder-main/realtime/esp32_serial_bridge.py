import json
import time
from typing import Iterable

from preprocessing.data_cleaning import EEG_CHANNELS
from realtime.prediction import BrainDisorderPredictor


def _load_serial_module():
    try:
        import serial
    except ImportError as exc:
        raise RuntimeError(
            "pyserial is required for ESP32 serial mode. Install it with: pip install pyserial"
        ) from exc
    return serial


def parse_signal_line(line: str) -> dict:
    payload = json.loads(line)
    values = payload.get("signals", payload) if isinstance(payload, dict) else {}
    if not isinstance(values, dict):
        raise ValueError("Expected JSON object with EEG channel values.")
    return {channel: values.get(channel, 0.0) for channel in EEG_CHANNELS}


def read_esp32_serial(
    port: str,
    baud_rate: int = 115200,
    timeout_seconds: float = 2.0,
    write_result: bool = True,
) -> Iterable[dict]:
    serial = _load_serial_module()
    predictor = BrainDisorderPredictor()

    with serial.Serial(port, baud_rate, timeout=timeout_seconds) as device:
        time.sleep(2.0)
        while True:
            raw = device.readline()
            if not raw:
                continue

            text = raw.decode("utf-8", errors="replace").strip()
            if not text:
                continue

            try:
                result = predictor.predict(parse_signal_line(text))
                message = json.dumps(result)
            except Exception as exc:
                result = {"error": str(exc), "raw": text}
                message = json.dumps({"error": str(exc)})

            if write_result:
                device.write((message + "\n").encode("utf-8"))

            yield result
