import pandas as pd

from preprocessing.data_cleaning import EEG_CHANNELS, standardize_signal_columns
from preprocessing.feature_extraction import extract_features


def build_signal_frame(values: dict) -> pd.DataFrame:
    row = {}
    for channel in EEG_CHANNELS:
        try:
            row[channel] = float(values.get(channel, 0.0))
        except (TypeError, ValueError):
            row[channel] = 0.0
    return pd.DataFrame([row])


def process_signal(values: dict, feature_cols: list[str], scaler):
    raw = build_signal_frame(values)
    return process_signal_frame(raw, feature_cols, scaler)


def process_signal_frame(raw: pd.DataFrame, feature_cols: list[str], scaler):
    raw = standardize_signal_columns(raw)
    if raw.empty:
        raise ValueError(
            "No EEG channels were found. Use columns like Fp1, Fp2, F3, F4, C3, C4, "
            "P3, P4, O1, O2, F7, F8, T7/T3, T8/T4, P7/T5, P8/T6, Fz, Cz, Pz."
        )
    features = extract_features(raw)
    features = features[feature_cols]
    features[feature_cols] = scaler.transform(features)
    return features
