import random
import time

from preprocessing.data_cleaning import EEG_CHANNELS


def simulated_eeg_stream(delay_seconds: float = 0.25):
    while True:
        yield {channel: random.gauss(0, 40) for channel in EEG_CHANNELS}
        time.sleep(delay_seconds)
