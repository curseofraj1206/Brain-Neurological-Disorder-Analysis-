"""
realtime/live_stream.py
-----------------------
SSE generator that yields EEG channel readings + a disease prediction
every `interval_seconds`.  Works with both a real ESP32 serial port and
the built-in simulated stream.
"""

import json
import time
from typing import Generator

from preprocessing.data_cleaning import EEG_CHANNELS
from realtime.eeg_stream import simulated_eeg_stream
from realtime.prediction import BrainDisorderPredictor


def _load_serial():
    try:
        import serial  # noqa: PLC0415
        return serial
    except ImportError:
        return None


def _list_ports() -> list[dict]:
    """Return [{port, description}] for all detected serial ports."""
    serial = _load_serial()
    if serial is None:
        return []
    try:
        from serial.tools import list_ports  # noqa: PLC0415
        return [
            {"port": p.device, "description": p.description}
            for p in list_ports.comports()
        ]
    except Exception:
        return []


# ── Public helper ────────────────────────────────────────────────────────────

def list_serial_ports() -> list[dict]:
    return _list_ports()


# ── Stream generators ────────────────────────────────────────────────────────

def _real_serial_stream(
    port: str,
    baud_rate: int = 115200,
    timeout: float = 2.0,
) -> Generator[dict, None, None]:
    """Read JSON lines from a serial device and yield channel dicts."""
    serial = _load_serial()
    if serial is None:
        raise RuntimeError(
            "pyserial is not installed. Run: pip install pyserial"
        )

    with serial.Serial(port, baud_rate, timeout=timeout) as dev:
        time.sleep(2.0)          # let the device boot / settle
        while True:
            raw = dev.readline()
            if not raw:
                continue
            text = raw.decode("utf-8", errors="replace").strip()
            if not text:
                continue
            try:
                payload = json.loads(text)
                values = payload.get("signals", payload) if isinstance(payload, dict) else {}
                yield {ch: float(values.get(ch, 0.0)) for ch in EEG_CHANNELS}
            except (json.JSONDecodeError, ValueError):
                # skip malformed lines
                continue


def live_eeg_stream(
    port: str | None = None,
    baud_rate: int = 115200,
    interval_seconds: float = 0.25,
    predict_every_n: int = 8,          # run predictor every N samples (~2 s)
    predictor: BrainDisorderPredictor | None = None,
) -> Generator[dict, None, None]:
    """
    Yields dicts:
        {
            "channels": {Fp1: float, Fp2: float, …},
            "prediction": {prediction, confidence, scores} | None,
            "ts": float   # unix timestamp
        }

    If *port* is None (or 'simulate'), uses the simulated stream.
    """
    if predictor is None:
        predictor = BrainDisorderPredictor()

    use_sim = port is None or port.lower() in ("", "simulate", "sim")

    if use_sim:
        source = simulated_eeg_stream(delay_seconds=interval_seconds)
    else:
        source = _real_serial_stream(port, baud_rate)

    last_prediction: dict | None = None
    tick = 0

    for channels in source:
        tick += 1

        if tick % predict_every_n == 0:
            try:
                last_prediction = predictor.predict(channels)
            except Exception as exc:
                last_prediction = {"error": str(exc)}

        yield {
            "channels": channels,
            "prediction": last_prediction,
            "ts": time.time(),
        }

        if use_sim:
            # simulated_eeg_stream already sleeps; real serial blocks on read
            pass
        else:
            time.sleep(interval_seconds)
