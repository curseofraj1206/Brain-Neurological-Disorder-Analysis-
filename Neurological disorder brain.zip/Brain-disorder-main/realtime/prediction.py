from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import torch

from models.transformer_model import EEGTransformer, TabularEEGTransformer
from preprocessing.data_cleaning import (
    EEG_CHANNELS,
    fast_read_signal_csv,
    read_signal_csv,
    standardize_signal_columns,
)
from realtime.signal_processor import build_signal_frame, process_signal, process_signal_frame


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SAVED_MODELS = PROJECT_ROOT / "saved_models"
DEFAULT_MODEL_CANDIDATES = (
    "ensemble_best.pkl",
    "xgboost_best.pkl",
    "transformer_model.pth",
    "transformer_best.pth",
)
IMPORTED_TRANSFORMER_FEATURES = [
    "C3", "C4", "Cz", "F3", "F4", "F7", "F8", "Fp1", "Fp2", "Fz",
    "O1", "O2", "P3", "P4", "Pz",
]


class BrainDisorderPredictor:
    def __init__(self, model_name: str | None = None):
        self.metadata = joblib.load(SAVED_MODELS / "metadata.pkl")
        self.classes = self.metadata["classes"]
        self.model_path = self._resolve_model_path(model_name)
        self.is_torch_model = self.model_path.suffix == ".pth"

        if self.is_torch_model:
            self.model, self.torch_preprocess = self._load_torch_model(self.model_path)
            if self.torch_preprocess == "tabular":
                self.scaler = self._load_transformer_scaler()
                self.feature_cols = self._transformer_feature_columns()
            else:
                self.scaler = joblib.load(SAVED_MODELS / "scaler.pkl")
                self.feature_cols = self.metadata["feature_columns"]
            if len(self.feature_cols) != self.model.input_dim:
                raise ValueError(
                    f"{self.model_path.name} expects {self.model.input_dim} features, "
                    f"but the selected scaler provides {len(self.feature_cols)}."
                )
        else:
            self.model = joblib.load(self.model_path)
            self._configure_cpu_inference()
            self.scaler = joblib.load(SAVED_MODELS / "scaler.pkl")
            self.feature_cols = self.metadata["feature_columns"]

    def _configure_cpu_inference(self) -> None:
        """Keep the web process independent of the training GPU.

        The saved XGBoost model retains its CUDA training setting.  GPU
        inference is unnecessary for CSV prediction and can cause a Windows
        web-server worker to exit when its CUDA context is reset.
        Training remains CUDA-enabled; only serving is CPU-safe.
        """
        try:
            if hasattr(self.model, "named_estimators_"):
                xgboost = self.model.named_estimators_.get("xgboost")
                if xgboost is not None and hasattr(xgboost, "set_params"):
                    xgboost.set_params(device="cpu")
            elif hasattr(self.model, "set_params"):
                self.model.set_params(device="cpu")
        except (AttributeError, TypeError, ValueError):
            # Non-XGBoost sklearn models do not expose a device parameter.
            pass

    def _resolve_model_path(self, model_name: str | None) -> Path:
        if model_name is None:
            candidates = DEFAULT_MODEL_CANDIDATES
        else:
            candidates = (model_name, "xgboost_best.pkl")

        for candidate in candidates:
            model_path = SAVED_MODELS / candidate
            if model_path.exists():
                return model_path

        expected = ", ".join(DEFAULT_MODEL_CANDIDATES)
        raise FileNotFoundError(
            f"No trained model found in {SAVED_MODELS}. Expected one of: {expected}."
        )

    def _load_transformer_scaler(self):
        transformer_scaler = SAVED_MODELS / "transformer_scaler.pkl"
        if transformer_scaler.exists():
            return joblib.load(transformer_scaler)
        return joblib.load(SAVED_MODELS / "scaler.pkl")

    def _transformer_feature_columns(self) -> list[str]:
        feature_names = getattr(self.scaler, "feature_names_in_", None)
        if feature_names is not None:
            return list(feature_names)
        return IMPORTED_TRANSFORMER_FEATURES

    def _load_torch_model(self, model_path: Path):
        checkpoint = torch.load(model_path, map_location="cpu")
        state_dict = checkpoint.get("state_dict", checkpoint)

        if "fc.weight" in state_dict:
            preprocess = "tabular"
            input_dim = state_dict["embedding.weight"].shape[1]
            hidden_dim = state_dict["embedding.weight"].shape[0]
            num_classes = state_dict["fc.weight"].shape[0]
            dim_feedforward = state_dict["transformer.layers.0.linear1.weight"].shape[0]
            num_layers = len(
                {
                    key.split(".")[2]
                    for key in state_dict
                    if key.startswith("transformer.layers.")
                }
            )
            model = TabularEEGTransformer(
                input_dim=input_dim,
                num_classes=num_classes,
                hidden_dim=hidden_dim,
                nhead=8,
                dim_feedforward=dim_feedforward,
                num_layers=num_layers,
            )
        else:
            preprocess = "engineered"
            input_dim = checkpoint.get("input_dim", len(self.metadata["feature_columns"]))
            num_classes = checkpoint.get("num_classes", len(self.classes))
            hidden_dim = state_dict["embedding.weight"].shape[0]
            model = EEGTransformer(
                input_dim=input_dim,
                num_classes=num_classes,
                hidden_dim=hidden_dim,
            )

        model.load_state_dict(state_dict)
        model.eval()
        return model, preprocess

    def _process_transformer_signal(self, values: dict) -> pd.DataFrame:
        raw = build_signal_frame(values)
        return self._process_transformer_signal_frame(raw)

    def _process_transformer_signal_frame(self, raw: pd.DataFrame) -> pd.DataFrame:
        raw = standardize_signal_columns(raw)
        if raw.empty:
            raise ValueError(
                "No EEG channels were found. Use columns like Fp1, Fp2, F3, F4, C3, C4, "
                "P3, P4, O1, O2, F7, F8, T7/T3, T8/T4, P7/T5, P8/T6, Fz, Cz, Pz."
            )

        features = raw[self.feature_cols].astype(float)
        scaled = self.scaler.transform(features)
        return pd.DataFrame(scaled, columns=self.feature_cols)

    def _predict_torch(self, features: pd.DataFrame) -> dict:
        tensor = torch.tensor(features.to_numpy(), dtype=torch.float32)
        with torch.no_grad():
            logits = self.model(tensor)
            probabilities = torch.softmax(logits, dim=1).mean(dim=0).cpu().numpy()

        predicted_id = int(np.argmax(probabilities))
        confidence = float(probabilities[predicted_id])
        scores = {
            label: float(probabilities[index])
            for index, label in enumerate(self.classes)
        }
        return {
            "prediction": self.classes[predicted_id],
            "confidence": round(confidence, 4),
            "scores": scores,
            "rows_analyzed": int(len(features)),
            "model": self.model_path.name,
        }

    def predict(self, values: dict) -> dict:
        if self.is_torch_model:
            if self.torch_preprocess == "tabular":
                features = self._process_transformer_signal(values)
            else:
                features = process_signal(values, self.feature_cols, self.scaler)
            return self._predict_torch(features)

        features = process_signal(values, self.feature_cols, self.scaler)
        return self._predict_features(features)

    def predict_csv(self, csv_file, max_rows: int | None = None) -> dict:
        """Predict from a CSV file.

        Uses fast uniform sampling (5000 rows spread across the whole file)
        to avoid loading multi-million-row uploads into RAM, which would
        crash the server.  Pass ``max_rows`` to override the sample size.
        """
        if max_rows is not None:
            raw = read_signal_csv(csv_file, max_rows=max_rows)
        else:
            raw = fast_read_signal_csv(csv_file)
        if raw.empty:
            raise ValueError("CSV file has no usable rows.")

        if self.is_torch_model:
            if self.torch_preprocess == "tabular":
                features = self._process_transformer_signal_frame(raw)
            else:
                features = process_signal_frame(raw, self.feature_cols, self.scaler)
            return self._predict_torch(features)

        features = process_signal_frame(raw, self.feature_cols, self.scaler)
        if features.empty:
            raise ValueError("CSV file does not contain usable EEG signal rows.")

        return self._predict_features(features)

    def _predict_features(self, features) -> dict:
        predicted_id = int(self.model.predict(features)[0])

        if hasattr(self.model, "predict_proba"):
            probabilities = self.model.predict_proba(features).mean(axis=0)
        else:
            probabilities = np.zeros(len(self.classes))
            probabilities[predicted_id] = 1.0

        predicted_id = int(np.argmax(probabilities))
        confidence = float(probabilities[predicted_id])
        scores = {
            label: float(probabilities[index])
            for index, label in enumerate(self.classes)
        }
        return {
            "prediction": self.classes[predicted_id],
            "confidence": round(confidence, 4),
            "scores": scores,
            "rows_analyzed": int(len(features)),
            "model": self.model_path.name,
        }


def sample_payload() -> dict:
    return {channel: 0.0 for channel in EEG_CHANNELS}
