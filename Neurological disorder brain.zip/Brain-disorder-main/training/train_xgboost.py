"""
Train XGBoost with early stopping + overfit-gap logging.

The overfit gap (train_acc - val_acc) is printed after fitting so you can
immediately see whether the model is memorising or generalising.
A healthy gap is < 3%.  A gap > 8% → the model is overfitting.

Early-stopping is set to 25 rounds (was 40): stops sooner once val_loss
stagnates, preventing the model from over-learning the training set.
Test-set accuracy is also printed — this is the true generalization score
because the test set was NEVER used during training or early-stopping.
"""
from pathlib import Path

import joblib
import pandas as pd
from sklearn.metrics import accuracy_score

from models.xgboost_model import build_xgboost_model
from preprocessing.dataset_split import create_splits
from training.evaluate import evaluate_model


PROJECT_ROOT = Path(__file__).resolve().parents[1]
PROCESSED_DIR = PROJECT_ROOT / "datasets" / "processed"
SAVED_MODELS = PROJECT_ROOT / "saved_models"


def train_xgboost(max_rows_per_file: int | None = None):
    # Keep the same held-out split when several models are compared.
    if not all((PROCESSED_DIR / filename).exists() for filename in ("train.csv", "val.csv", "test.csv")) or not (SAVED_MODELS / "metadata.pkl").exists():
        create_splits(max_rows_per_file=max_rows_per_file)

    train = pd.read_csv(PROCESSED_DIR / "train.csv")
    val   = pd.read_csv(PROCESSED_DIR / "val.csv")
    metadata = joblib.load(SAVED_MODELS / "metadata.pkl")
    feature_cols = metadata["feature_columns"]
    SAVED_MODELS.mkdir(parents=True, exist_ok=True)

    model = build_xgboost_model(num_classes=len(metadata["classes"]), device="cpu")

    # ── Fit with early stopping ───────────────────────────────────────────────
    fit_kwargs = dict(
        X=train[feature_cols],
        y=train["target"],
    )
    try:
        from xgboost import XGBClassifier  # noqa: F401
        model.set_params(early_stopping_rounds=25)   # stop if no improvement for 25 rounds
        fit_kwargs["eval_set"] = [(val[feature_cols], val["target"])]
        fit_kwargs["verbose"] = 25
    except ImportError:
        pass   # sklearn GBC fallback – no eval_set needed

    model.fit(**fit_kwargs)

    # -- Overfit-gap diagnostic ------------------------------------------------
    train_acc = accuracy_score(train["target"], model.predict(train[feature_cols]))
    val_acc   = accuracy_score(val["target"],   model.predict(val[feature_cols]))
    gap       = train_acc - val_acc

    # Test set – true generalisation score (never used during training)
    test_path = PROCESSED_DIR / "test.csv"
    test_acc  = None
    if test_path.exists():
        test = pd.read_csv(test_path)
        test_acc = accuracy_score(test["target"], model.predict(test[feature_cols]))

    print(f"\n{'='*60}")
    print(f"  OVERFITTING DIAGNOSTIC — XGBoost")
    print(f"{'='*60}")
    print(f"  Train accuracy : {train_acc:.4f}  ({train_acc*100:.2f}%)")
    print(f"  Val   accuracy : {val_acc:.4f}  ({val_acc*100:.2f}%)")
    if test_acc is not None:
        print(f"  Test  accuracy : {test_acc:.4f}  ({test_acc*100:.2f}%)  ← TRUE score")
    print(f"  Train-Val gap  : {gap:+.4f}  ({gap*100:.2f}%)")
    print(f"{'─'*60}")
    if gap < 0.03:
        print("  ✅  PASS  Gap < 3% — model generalises well")
    elif gap < 0.08:
        print("  ⚠️   WARN  Gap 3–8% — mild overfit, acceptable for EEG data")
    else:
        print("  ❌  FAIL  Gap > 8% — model is OVERFITTING")
        print("       → Increase reg_lambda / min_child_weight, or reduce n_estimators")
    print(f"{'='*60}\n")

    model_path = SAVED_MODELS / "xgboost_best.pkl"
    joblib.dump(model, model_path)
    metrics = evaluate_model(model, val, feature_cols, split_name="val_xgboost")
    if test_acc is not None:
        test_metrics = evaluate_model(model, test, feature_cols, split_name="test_xgboost")
        metrics.update({f"test_{key}": value for key, value in test_metrics.items()})
    result = {**metrics, "train_accuracy": train_acc, "val_accuracy": val_acc, "gap": gap}
    if test_acc is not None:
        result["test_accuracy"] = test_acc
    return model_path, result


if __name__ == "__main__":
    path, scores = train_xgboost()
    print(f"Saved model: {path}")
    print(scores)
