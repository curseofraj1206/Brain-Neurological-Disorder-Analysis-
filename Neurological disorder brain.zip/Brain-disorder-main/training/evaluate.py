"""Metrics and plots for held-out EEG evaluation."""
from pathlib import Path

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score, roc_auc_score, roc_curve
from sklearn.preprocessing import label_binarize


PROJECT_ROOT = Path(__file__).resolve().parents[1]
RESULTS_DIR = PROJECT_ROOT / "results"
SAVED_MODELS = PROJECT_ROOT / "saved_models"


def _result_dirs() -> tuple[Path, Path, Path, Path]:
    """Create dedicated folders for all post-training artifacts."""
    directories = (
        RESULTS_DIR / "performance_metrics",
        RESULTS_DIR / "confusion_matrix",
        RESULTS_DIR / "roc_curve",
        RESULTS_DIR / "f1_score",
    )
    for directory in directories:
        directory.mkdir(parents=True, exist_ok=True)
    return directories


def evaluate_predictions(y_true, y_pred, y_proba, classes: list[str], split_name: str = "test") -> dict:
    """Write metrics and confusion matrix, ROC, and F1 plots for predictions."""
    y_true, y_pred, y_proba = np.asarray(y_true, dtype=int), np.asarray(y_pred, dtype=int), np.asarray(y_proba, dtype=float)
    labels = np.arange(len(classes))
    metrics_dir, cm_dir, roc_dir, f1_dir = _result_dirs()
    report = classification_report(y_true, y_pred, labels=labels, target_names=classes, output_dict=True, zero_division=0)
    matrix = confusion_matrix(y_true, y_pred, labels=labels)
    accuracy = float(accuracy_score(y_true, y_pred))
    macro_f1 = float(f1_score(y_true, y_pred, labels=labels, average="macro", zero_division=0))
    per_class_f1 = f1_score(y_true, y_pred, labels=labels, average=None, zero_division=0)
    pd.DataFrame(report).transpose().to_csv(metrics_dir / f"{split_name}_classification_report.csv")
    pd.DataFrame({"metric": ["accuracy", "macro_f1"], "value": [accuracy, macro_f1]}).to_csv(metrics_dir / f"{split_name}_summary.csv", index=False)
    pd.DataFrame(matrix, index=classes, columns=classes).to_csv(cm_dir / f"{split_name}_confusion_matrix.csv")

    fig, ax = plt.subplots(figsize=(7, 6))
    image = ax.imshow(matrix, cmap="Blues")
    fig.colorbar(image, ax=ax)
    ax.set(xticks=labels, yticks=labels, xticklabels=classes, yticklabels=classes, xlabel="Predicted label", ylabel="True label", title=f"Confusion matrix - {split_name}")
    plt.setp(ax.get_xticklabels(), rotation=30, ha="right")
    threshold = matrix.max() / 2 if matrix.size else 0
    for row in range(len(classes)):
        for col in range(len(classes)):
            ax.text(col, row, str(matrix[row, col]), ha="center", va="center", color="white" if matrix[row, col] > threshold else "black")
    fig.tight_layout()
    fig.savefig(cm_dir / f"{split_name}_confusion_matrix.png", dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 6))
    y_bin, aucs = label_binarize(y_true, classes=labels), {}
    for index, class_name in enumerate(classes):
        if len(np.unique(y_bin[:, index])) < 2:
            continue
        fpr, tpr, _ = roc_curve(y_bin[:, index], y_proba[:, index])
        auc = float(roc_auc_score(y_bin[:, index], y_proba[:, index]))
        aucs[class_name] = auc
        ax.plot(fpr, tpr, label=f"{class_name} (AUC={auc:.3f})")
    ax.plot([0, 1], [0, 1], "k--", linewidth=1)
    ax.set(xlim=(0, 1), ylim=(0, 1.05), xlabel="False positive rate", ylabel="True positive rate", title=f"One-vs-rest ROC curve - {split_name}")
    ax.legend(loc="lower right")
    fig.tight_layout()
    fig.savefig(roc_dir / f"{split_name}_roc_curve.png", dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 5))
    bars = ax.bar(classes, per_class_f1, color="#2478b5")
    ax.set(ylim=(0, 1), ylabel="F1 score", title=f"Per-class F1 score - {split_name}")
    for bar, value in zip(bars, per_class_f1):
        ax.text(bar.get_x() + bar.get_width() / 2, value + 0.02, f"{value:.3f}", ha="center")
    fig.tight_layout()
    fig.savefig(f1_dir / f"{split_name}_f1_score.png", dpi=180)
    plt.close(fig)
    return {"accuracy": accuracy, "macro_f1": macro_f1, "roc_auc_ovr": float(np.mean(list(aucs.values()))) if aucs else None}


def evaluate_model(model, data: pd.DataFrame, feature_cols: list[str], split_name: str = "test"):
    metadata = joblib.load(SAVED_MODELS / "metadata.pkl")
    return evaluate_predictions(data["target"], model.predict(data[feature_cols]), model.predict_proba(data[feature_cols]), metadata["classes"], split_name)


def evaluate_saved_model(model_name: str = "ensemble_best.pkl", split: str = "test"):
    data = pd.read_csv(PROJECT_ROOT / "datasets" / "processed" / f"{split}.csv")
    metadata = joblib.load(SAVED_MODELS / "metadata.pkl")
    model_path = SAVED_MODELS / model_name
    if not model_path.exists() and model_name == "ensemble_best.pkl":
        model_path = SAVED_MODELS / "xgboost_best.pkl"
    return evaluate_model(joblib.load(model_path), data, metadata["feature_columns"], split_name=split)


if __name__ == "__main__":
    print(evaluate_saved_model())
