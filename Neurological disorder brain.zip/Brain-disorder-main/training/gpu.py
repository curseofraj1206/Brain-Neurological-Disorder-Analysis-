import shutil
import subprocess


def nvidia_gpu_available() -> bool:
    if not shutil.which("nvidia-smi"):
        return False
    try:
        result = subprocess.run(
            ["nvidia-smi", "-L"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except Exception:
        return False
    return result.returncode == 0 and bool(result.stdout.strip())


def torch_cuda_available() -> bool:
    try:
        import torch
    except Exception:
        return False
    return bool(torch.cuda.is_available())


def gpu_available() -> bool:
    return torch_cuda_available() or nvidia_gpu_available()


def xgboost_device(requested: str = "auto") -> str:
    if requested == "cpu":
        return "cpu"
    if requested == "gpu":
        if not gpu_available():
            raise RuntimeError(
                "GPU training was requested, but no CUDA/NVIDIA GPU is visible. "
                "Install NVIDIA drivers and a CUDA-capable Python stack, then retry."
            )
        return "cuda"
    return "cuda" if gpu_available() else "cpu"


def torch_device(requested: str = "auto") -> str:
    if requested == "cpu":
        return "cpu"
    if requested == "gpu":
        if not torch_cuda_available():
            raise RuntimeError(
                "GPU transformer training was requested, but this PyTorch install "
                "cannot use CUDA. Install a CUDA-enabled torch build, then retry."
            )
        return "cuda"
    return "cuda" if torch_cuda_available() else "cpu"
