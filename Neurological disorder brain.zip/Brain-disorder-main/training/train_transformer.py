"""
Train EEGTransformer with strong regularisation to prevent overfitting.

Anti-overfit measures:
  - AdamW weight_decay=5e-3 (stronger L2 than before)
  - ReduceLROnPlateau: halves LR after 5 stagnant epochs
  - Gradient clipping (max_norm=0.5) — tighter than before
  - Label smoothing=0.1 — penalises over-confident predictions
  - MixUp augmentation — blends pairs of samples; forces smooth boundaries
  - Early stopping: patience=8 epochs on val accuracy (reduced from 12)
  - Random-sample train accuracy (not first-N rows) for unbiased gap check
  - Prints train vs val accuracy gap every epoch for diagnosis
"""
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import torch
from sklearn.metrics import accuracy_score
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from models.transformer_model import EEGTransformer
from preprocessing.dataset_split import create_splits
from training.evaluate import evaluate_predictions


# ── MixUp augmentation ────────────────────────────────────────────────────────
def mixup_batch(
    x: torch.Tensor, y: torch.Tensor, alpha: float = 0.2
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, float]:
    """
    Apply MixUp to a single batch.
    Returns mixed_x, y_a, y_b, lam  (for mixed loss = lam*loss_a + (1-lam)*loss_b)
    A low alpha (0.2) keeps mixing mild — most weight stays on the original sample.
    """
    lam = float(np.random.beta(alpha, alpha)) if alpha > 0 else 1.0
    batch_size = x.size(0)
    idx = torch.randperm(batch_size, device=x.device)
    mixed_x = lam * x + (1 - lam) * x[idx]
    return mixed_x, y, y[idx], lam


PROJECT_ROOT = Path(__file__).resolve().parents[1]
PROCESSED_DIR = PROJECT_ROOT / "datasets" / "processed"
SAVED_MODELS = PROJECT_ROOT / "saved_models"


def train_transformer(
    max_rows_per_file: int | None = None,
    epochs: int = 30,
    batch_size: int = 128,
    patience: int = 8,
    lr: float = 3e-4,
    weight_decay: float = 5e-3,
    mixup_alpha: float = 0.2,
):
    resolved_device = "cpu"

    # Skip re-processing if splits already exist (saves 3-5 min re-reading 2.5 GB raw CSVs)
    train_path = PROCESSED_DIR / "train.csv"
    val_path   = PROCESSED_DIR / "val.csv"
    if not train_path.exists() or not val_path.exists() or not (SAVED_MODELS / "metadata.pkl").exists():
        print("Processed splits not found - running create_splits()...")
        create_splits(max_rows_per_file=max_rows_per_file)
    else:
        print("Reusing existing processed splits (train.csv / val.csv).")

    train = pd.read_csv(PROCESSED_DIR / "train.csv")
    val   = pd.read_csv(PROCESSED_DIR / "val.csv")
    metadata = joblib.load(SAVED_MODELS / "metadata.pkl")
    feature_cols = metadata["feature_columns"]

    x_train = torch.tensor(train[feature_cols].values, dtype=torch.float32)
    y_train = torch.tensor(train["target"].values,     dtype=torch.long)
    x_val   = torch.tensor(val[feature_cols].values,   dtype=torch.float32).to(resolved_device)
    y_val   = torch.tensor(val["target"].values,       dtype=torch.long).to(resolved_device)

    loader = DataLoader(
        TensorDataset(x_train, y_train),
        batch_size=batch_size,
        shuffle=True,
        drop_last=True,
    )

    model = EEGTransformer(
        input_dim=len(feature_cols),
        num_classes=len(metadata["classes"]),
        hidden_dim=32,       # small capacity -> less memorisation
    ).to(resolved_device)

    optimizer = torch.optim.AdamW(
        model.parameters(), lr=lr, weight_decay=weight_decay
    )
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="max", factor=0.5, patience=5, min_lr=1e-6
    )
    loss_fn = nn.CrossEntropyLoss(label_smoothing=0.1)   # penalise over-confidence

    best_val_acc = 0.0
    no_improve   = 0
    model_path   = SAVED_MODELS / "transformer_best.pth"
    SAVED_MODELS.mkdir(parents=True, exist_ok=True)

    for epoch in range(1, epochs + 1):
        # ── Train (with MixUp) ─────────────────────────────────────────────────
        model.train()
        for batch_x, batch_y in loader:
            batch_x = batch_x.to(resolved_device)
            batch_y = batch_y.to(resolved_device)
            # Apply MixUp augmentation to the batch
            mixed_x, y_a, y_b, lam = mixup_batch(batch_x, batch_y, alpha=mixup_alpha)
            optimizer.zero_grad()
            logits = model(mixed_x)
            loss = lam * loss_fn(logits, y_a) + (1 - lam) * loss_fn(logits, y_b)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=0.5)
            optimizer.step()

        # ── Evaluate train & val ───────────────────────────────────────────────
        model.eval()
        with torch.no_grad():
            # Validation
            val_preds = model(x_val).argmax(dim=1).cpu().numpy()
            val_acc   = accuracy_score(y_val.cpu().numpy(), val_preds)

            # Training – random shuffled sample (unbiased; not just first N rows)
            n_sample = min(3000, len(x_train))
            sample_idx = torch.randperm(len(x_train))[:n_sample]
            x_tr_sample = x_train[sample_idx].to(resolved_device)
            y_tr_sample = y_train[sample_idx]
            tr_preds    = model(x_tr_sample).argmax(dim=1).cpu().numpy()
            tr_acc      = accuracy_score(y_tr_sample.numpy(), tr_preds)

        gap = tr_acc - val_acc
        scheduler.step(val_acc)
        lr_now = optimizer.param_groups[0]["lr"]

        gap_flag = "[OK]" if gap < 0.03 else ("[WARN]" if gap < 0.08 else "[OVERFIT!]")
        print(
            f"Ep {epoch:3d}/{epochs}  "
            f"train={tr_acc:.4f}  val={val_acc:.4f}  "
            f"gap={gap:+.4f} {gap_flag}  "
            f"lr={lr_now:.1e}"
        )

        if val_acc > best_val_acc:
            best_val_acc = val_acc
            no_improve = 0
            torch.save(
                {
                    "state_dict": model.state_dict(),
                    "input_dim": len(feature_cols),
                    "num_classes": len(metadata["classes"]),
                    "accuracy": best_val_acc,
                    "device": resolved_device,
                },
                model_path,
            )
        else:
            no_improve += 1
            if no_improve >= patience:
                print(f"\nEarly stopping at epoch {epoch} (patience={patience})")
                break

    print(f"\nBest val accuracy : {best_val_acc:.4f} ({best_val_acc*100:.2f}%)")

    # ── Final test-set evaluation — true generalisation score ──────────────────
    test_path = PROCESSED_DIR / "test.csv"
    test_acc  = None
    if test_path.exists():
        test_df = pd.read_csv(test_path)
        x_test  = torch.tensor(test_df[feature_cols].values, dtype=torch.float32).to(resolved_device)
        y_test  = test_df["target"].values
        # Reload best checkpoint for final evaluation
        ckpt = torch.load(model_path, map_location=resolved_device)
        model.load_state_dict(ckpt["state_dict"])
        model.eval()
        with torch.no_grad():
            test_logits = model(x_test)
            test_preds = test_logits.argmax(dim=1).cpu().numpy()
            test_probabilities = torch.softmax(test_logits, dim=1).cpu().numpy()
        test_acc = float(accuracy_score(y_test, test_preds))
        test_metrics = evaluate_predictions(
            y_test, test_preds, test_probabilities, metadata["classes"], "test_transformer"
        )
        print(f"Test  accuracy    : {test_acc:.4f} ({test_acc*100:.2f}%)  ← TRUE score")

    result = {"val_accuracy": best_val_acc}
    if test_acc is not None:
        result["test_accuracy"] = test_acc
        result.update({f"test_{key}": value for key, value in test_metrics.items()})
    return model_path, result


if __name__ == "__main__":
    path, scores = train_transformer()
    print(f"Saved model: {path}")
    print(scores)
