"""Train a regularized soft-voting ensemble."""
from pathlib import Path

import joblib
import pandas as pd
from sklearn.metrics import accuracy_score

from models.ensemble_model import build_ensemble_model
from preprocessing.dataset_split import create_splits
from training.evaluate import evaluate_model


PROJECT_ROOT = Path(__file__).resolve().parents[1]
PROCESSED_DIR = PROJECT_ROOT / "datasets" / "processed"
SAVED_MODELS = PROJECT_ROOT / "saved_models"


def _print_overfit_diagnostic(
    name: str,
    train_acc: float,
    val_acc: float,
    test_acc: float | None,
) -> None:
    gap = train_acc - val_acc

    print(f"\n{'='*60}")
    print(f"  OVERFITTING DIAGNOSTIC - {name}")
    print(f"{'='*60}")
    print(f"  Train accuracy : {train_acc:.4f}  ({train_acc*100:.2f}%)")
    print(f"  Val   accuracy : {val_acc:.4f}  ({val_acc*100:.2f}%)")
    if test_acc is not None:
        print(f"  Test  accuracy : {test_acc:.4f}  ({test_acc*100:.2f}%)  <- TRUE score")
    print(f"  Train-Val gap  : {gap:+.4f}  ({gap*100:.2f}%)")
    print(f"{'-'*60}")
    if gap < 0.03:
        print("  [PASS]  Gap < 3% - model generalises well")
    elif gap < 0.08:
        print("  [WARN]  Gap 3-8% - mild overfit, acceptable for EEG data")
    else:
        print("  [FAIL]  Gap > 8% - model is OVERFITTING")
        print("          -> Reduce tree depth, raise min_samples_leaf, or lower C")
    print(f"{'='*60}\n")


def train_ensemble(max_rows_per_file: int | None = None):
    # Do not recreate the split after another model has already used it.
    if not all((PROCESSED_DIR / filename).exists() for filename in ("train.csv", "val.csv", "test.csv")) or not (SAVED_MODELS / "metadata.pkl").exists():
        create_splits(max_rows_per_file=max_rows_per_file)

    train = pd.read_csv(PROCESSED_DIR / "train.csv")
    val = pd.read_csv(PROCESSED_DIR / "val.csv")
    metadata = joblib.load(SAVED_MODELS / "metadata.pkl")
    feature_cols = metadata["feature_columns"]
    SAVED_MODELS.mkdir(parents=True, exist_ok=True)

    model = build_ensemble_model(num_classes=len(metadata["classes"]), device="cpu")
    model.fit(train[feature_cols], train["target"])

    train_acc = accuracy_score(train["target"], model.predict(train[feature_cols]))
    val_acc = accuracy_score(val["target"], model.predict(val[feature_cols]))

    test_acc = None
    test_path = PROCESSED_DIR / "test.csv"
    if test_path.exists():
        test = pd.read_csv(test_path)
        test_acc = accuracy_score(test["target"], model.predict(test[feature_cols]))

    _print_overfit_diagnostic("Ensemble", train_acc, val_acc, test_acc)

    model_path = SAVED_MODELS / "ensemble_best.pkl"
    joblib.dump(model, model_path)
    metrics = evaluate_model(model, val, feature_cols, split_name="val_ensemble")
    if test_acc is not None:
        test_metrics = evaluate_model(model, test, feature_cols, split_name="test_ensemble")
        metrics.update({f"test_{key}": value for key, value in test_metrics.items()})
    result = {**metrics, "train_accuracy": train_acc, "val_accuracy": val_acc}
    result["gap"] = train_acc - val_acc
    if test_acc is not None:
        result["test_accuracy"] = test_acc
    return model_path, result


if __name__ == "__main__":
    path, scores = train_ensemble()
    print(f"Saved model: {path}")
    print(scores)
