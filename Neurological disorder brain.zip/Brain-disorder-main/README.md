# 🧠 Brain Signal AI

> **EEG-powered machine learning for experimental brain-signal classification**

Brain Signal AI is an end-to-end **EEG signal classification platform** that combines signal preprocessing, feature engineering, ensemble learning, XGBoost, and a Transformer model with a Flask-powered prediction API and optional ESP32 hardware integration.

The current project is designed to classify EEG input into three experimental classes:

- 🧩 **Alzheimer's**
- ⚡ **Epilepsy**
- 🧠 **Schizophrenia**

> ⚠️ **Research / educational project:** This system is not a medical device and must not be used as a substitute for professional clinical diagnosis.

---

## ✨ What makes it interesting?

```text
             EEG DATA
                 │
                 ▼
        ┌─────────────────┐
        │ Preprocessing   │
        │ • Cleaning      │
        │ • Normalization │
        │ • Features      │
        └────────┬────────┘
                 │
                 ▼
       ┌─────────────────────┐
       │   ML MODEL LAYER    │
       │                     │
       │  XGBoost            │
       │  Ensemble           │
       │  Transformer        │
       └──────────┬──────────┘
                  │
                  ▼
        ┌───────────────────┐
        │ Prediction Engine │
        └─────────┬─────────┘
                  │
          ┌───────┴────────┐
          ▼                ▼
     Flask REST API     ESP32
          │                │
          └───────┬────────┘
                  ▼
             Prediction
```

### 🚀 Core capabilities

- 📊 EEG CSV preprocessing pipeline
- 🧹 Data cleaning and normalization
- 🧬 Feature extraction
- 🤖 XGBoost classification
- 🔗 Ensemble model pipeline
- ⚙️ Transformer-based model for comparison
- 🌐 Flask REST API for predictions
- 🔌 ESP32 → Wi-Fi → Flask integration
- 💻 Command-line training, evaluation and prediction
- 💾 Saved model artifacts for repeatable inference

---

## 🛠️ Tech Stack

| Layer | Technologies |
|---|---|
| Language | Python |
| ML | XGBoost, PyTorch |
| Deep Learning | Transformer architecture |
| Backend | Flask |
| Data Processing | NumPy, Pandas, Scikit-learn |
| Hardware | ESP32 |
| Communication | REST API / Serial |
| Model Storage | Pickle / PyTorch checkpoints |

---

## 📁 Project Structure

```text
Brain-disorder-main/
│
├── backend/                 # Flask API + database + routes
├── hardware/                # ESP32 integration
├── models/                  # ML model definitions
├── preprocessing/           # Cleaning, features, normalization
├── realtime/                # Live EEG + prediction pipeline
├── training/                # Training and evaluation scripts
├── saved_models/            # Trained model artifacts
│
├── main.py                  # Main CLI entry point
├── requirements.txt         # Python dependencies
├── Procfile                 # Deployment configuration
└── render.yaml              # Render deployment configuration
```

---

## ⚡ Quick Start

### 1. Clone the repository

```bash
git clone https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
cd Brain-disorder-main
```

### 2. Create a virtual environment

**Windows:**

```powershell
python -m venv .venv
.venv\Scripts\activate
```

**Linux / macOS:**

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Train a model

```bash
python main.py train --model ensemble
```

Other available training modes:

```bash
python main.py train --model xgboost
python main.py train --model transformer
```

### 5. Start the prediction server

```bash
python main.py serve
```

Then open:

```text
http://127.0.0.1:5000
```

---

## 🧪 Evaluation & Prediction

Evaluate the trained models:

```bash
python main.py evaluate
```

Run a direct prediction from the command line:

```bash
python main.py predict --Fp1 10 --Fp2 5 --F3 2
```

The project stores reusable artifacts such as:

```text
saved_models/
├── scaler.pkl
├── label_encoder.pkl
├── metadata.pkl
├── ensemble_best.pkl
├── xgboost_best.pkl
└── transformer_best.pth
```

---

## 🌐 REST API

The Flask backend exposes a prediction endpoint:

```http
POST /api/predict
Content-Type: application/json
```

Example request:

```json
{
  "signals": {
    "Fp1": 0,
    "Fp2": 0,
    "F3": 0
  }
}
```

The backend processes the supplied EEG channels and returns the model prediction.

Missing channels are handled by the application's preprocessing pipeline.

---

## 🔌 ESP32 Integration

The project can receive EEG-related signal values from an ESP32 and forward them to the Python prediction server.

Start Flask so devices on the same network can access it:

```powershell
python main.py serve --host 0.0.0.0 --port 5000
```

Then configure the ESP32 client with your computer's local network address:

```text
http://YOUR-LAN-IP:5000/api/predict
```

For USB serial communication:

```powershell
python main.py esp32-serial --port COM5
```

Detailed hardware notes are available in [`hardware/README.md`](hardware/README.md).

> **Safety:** Never connect raw electrodes directly to an ESP32. Use an appropriate EEG acquisition/front-end and electrically safe isolation hardware.

---

## 🧠 Supported EEG Channels

The current model pipeline supports channels including:

```text
Fp1  Fp2  F3  F4  C3  C4  P3  P4  O1  O2
F7   F8   T7  T8  P7  P8  Fz  Cz  Pz
```

The exact input requirements depend on the trained model and preprocessing configuration.

---

## 🔬 ML Pipeline

The project follows a modular workflow:

**Raw EEG → Cleaning → Feature Extraction → Normalization → Model → Prediction**

Three model approaches are included:

### 1. XGBoost

A gradient-boosted tree model used for structured EEG features and fast inference.

### 2. Ensemble

Combines model outputs into a unified prediction pipeline.

### 3. Transformer

A PyTorch-based Transformer model is included as a deep-learning approach for comparison with traditional machine-learning methods.

---

## 🎯 Project Goals

- Build a reproducible EEG preprocessing pipeline
- Explore classical ML and deep-learning approaches
- Provide a simple prediction API
- Experiment with real-time hardware integration
- Create a foundation for future EEG research and experimentation

---

## 🔮 Future Ideas

- [ ] Real-time EEG dashboard
- [ ] Live signal visualization
- [ ] Model confidence visualization
- [ ] More robust cross-validation
- [ ] Additional EEG datasets
- [ ] Automated model comparison
- [ ] Better experiment tracking
- [ ] Secure authentication for the API
- [ ] Containerized deployment

---

## 📌 Disclaimer

This repository is intended for **education, experimentation, and research**. Predictions produced by the system should not be interpreted as medical diagnoses or used to make clinical decisions.

---

## ⭐ If you're exploring EEG + AI

Feel free to experiment with the preprocessing pipeline, compare the models, and extend the system with new datasets or signal-processing techniques.

**Build → Train → Evaluate → Experiment → Improve 🧠⚡**
