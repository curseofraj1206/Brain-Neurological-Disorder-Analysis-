"""
XGBoost classifier with aggressive anti-overfitting regularisation.

The goal is a model that GENERALISES to unseen patients, not one that
memorises the training CSV's recording conditions.

Key hyperparameter rationale:
  max_depth=3         – very shallow; forces generalised splits
  min_child_weight=30 – VERY large leaf population; stops micro-splits on noise
  gamma=0.3           – significant gain needed to justify each split
  reg_alpha=0.5       – strong L1 → drives useless feature weights to 0
  reg_lambda=5.0      – STRONG L2 → aggressive weight shrinkage
  subsample=0.7       – 30% of rows dropped per tree (stochasticity)
  colsample_bytree=0.7– 30% of features dropped per tree
  colsample_bylevel=0.7
  learning_rate=0.02  – slow learning → fewer trees needed (early stop)
  n_estimators=200    – modest budget; early_stopping_rounds=25 cuts further
"""
try:
    from xgboost import XGBClassifier
except Exception:
    XGBClassifier = None

from sklearn.ensemble import GradientBoostingClassifier

from training.gpu import xgboost_device


def build_xgboost_model(num_classes: int, device: str = "auto"):
    if XGBClassifier is None:
        if device == "gpu":
            raise RuntimeError(
                "xgboost is not installed; GPU XGBoost training is unavailable."
            )
        return GradientBoostingClassifier(
            n_estimators=200,
            max_depth=3,
            learning_rate=0.02,
            subsample=0.7,
            min_samples_leaf=10,
            random_state=42,
        )

    resolved_device = xgboost_device(device)
    return XGBClassifier(
        objective="multi:softprob",
        num_class=num_classes,
        tree_method="hist",
        device=resolved_device,
        # ── Capacity (kept small on purpose) ────────────────────────────
        n_estimators=200,         # modest budget; early_stopping_rounds=25 cuts further
        max_depth=3,               # SHALLOW – forces general patterns
        max_leaves=8,              # cap leaf count per tree
        # ── Learning rate ───────────────────────────────────────────────
        learning_rate=0.02,        # slow → needs fewer trees → less overfit
        # ── Stochasticity (prevents memorisation) ───────────────────────
        subsample=0.7,
        colsample_bytree=0.7,
        colsample_bylevel=0.7,
        colsample_bynode=0.7,
        # ── Regularisation ──────────────────────────────────────────────
        reg_alpha=0.5,             # L1 – sparse features
        reg_lambda=5.0,            # L2 – STRONG weight shrinkage (raised from 3.0)
        min_child_weight=30,       # VERY LARGE – requires big leaf population
        gamma=0.3,                 # min gain to justify any split
        # ── Misc ────────────────────────────────────────────────────────
        eval_metric="mlogloss",
        random_state=42,
        n_jobs=-1,
        verbosity=0,
    )
