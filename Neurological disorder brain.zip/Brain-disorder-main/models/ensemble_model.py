"""
Conservative soft-voting ensemble for EEG classification.

The ensemble keeps each learner deliberately regularized so the combined model
does not simply memorize the training split:
- LogisticRegression: low C for stronger L2 shrinkage.
- RandomForest: shallow trees and large leaves.
- XGBoost: the same anti-overfit settings used by the standalone model.
"""
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.linear_model import LogisticRegression

from models.xgboost_model import build_xgboost_model


def build_ensemble_model(num_classes: int, device: str = "auto"):
    xgboost = build_xgboost_model(num_classes=num_classes, device=device)
    if hasattr(xgboost, "set_params"):
        xgboost.set_params(n_estimators=160)

    logistic = LogisticRegression(
        C=0.35,
        class_weight="balanced",
        max_iter=2000,
        random_state=42,
        solver="lbfgs",
    )

    random_forest = RandomForestClassifier(
        n_estimators=180,
        max_depth=8,
        min_samples_split=30,
        min_samples_leaf=15,
        max_features="sqrt",
        bootstrap=True,
        class_weight="balanced_subsample",
        random_state=42,
        n_jobs=-1,
    )

    return VotingClassifier(
        estimators=[
            ("logistic", logistic),
            ("random_forest", random_forest),
            ("xgboost", xgboost),
        ],
        voting="soft",
        weights=[1, 1, 2],
        n_jobs=1,
    )
