"""
Transformer models for EEG-based brain disorder classification.

Anti-overfitting settings:
- norm_first=False  (fixes UserWarning and enables nested-tensor optimisation)
- dropout=0.4       (strong regularisation)
- hidden_dim=32     (small capacity for tabular data)
- num_layers=2      (shallow enough to not memorise)
"""
import torch
from torch import nn


class EEGTransformer(nn.Module):
    """
    Treats each of the N EEG features as a separate token.
    Embedding: scalar (1) -> hidden_dim via Linear(1, hidden_dim).
    """

    def __init__(self, input_dim: int, num_classes: int, hidden_dim: int = 32):
        super().__init__()
        self.input_dim = input_dim
        self.embedding = nn.Linear(1, hidden_dim)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim,
            nhead=4,
            dim_feedforward=128,
            dropout=0.4,
            batch_first=True,
            norm_first=False,   # FIXED: False avoids UserWarning + enables optimisation
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=2)
        self.classifier = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.Dropout(0.4),
            nn.Linear(hidden_dim, num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x.unsqueeze(-1)       # (B, F, 1)
        x = self.embedding(x)     # (B, F, H)
        x = self.encoder(x)       # (B, F, H)
        x = x.mean(dim=1)         # (B, H)
        return self.classifier(x) # (B, C)


class TabularEEGTransformer(nn.Module):
    """
    Single-token variant: projects full feature vector to hidden_dim.
    Used when loading externally-pretrained weights.
    """

    def __init__(
        self,
        input_dim: int,
        num_classes: int,
        hidden_dim: int = 64,
        nhead: int = 4,
        dim_feedforward: int = 256,
        num_layers: int = 2,
        dropout: float = 0.4,
    ):
        super().__init__()
        self.input_dim = input_dim
        self.embedding = nn.Linear(input_dim, hidden_dim)
        self.bn = nn.BatchNorm1d(hidden_dim)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim,
            nhead=nhead,
            dim_feedforward=dim_feedforward,
            dropout=dropout,
            batch_first=True,
            norm_first=False,   # FIXED
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.classifier = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.GELU(),
            nn.Dropout(dropout / 2),
            nn.Linear(hidden_dim // 2, num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.embedding(x)     # (B, H)
        x = self.bn(x)
        x = x.unsqueeze(1)        # (B, 1, H)
        x = self.transformer(x)   # (B, 1, H)
        x = x.squeeze(1)          # (B, H)
        return self.classifier(x)
