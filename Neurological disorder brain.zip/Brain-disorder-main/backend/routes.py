import json

from flask import current_app

from flask import Blueprint, Response, jsonify, render_template, request, stream_with_context

from backend.database import recent_predictions, save_prediction
from realtime.live_stream import list_serial_ports, live_eeg_stream
from realtime.prediction import BrainDisorderPredictor


bp = Blueprint("main", __name__)
_predictor = None


def get_predictor():
    global _predictor
    if _predictor is None:
        _predictor = BrainDisorderPredictor()
    return _predictor


# ── Page routes ──────────────────────────────────────────────────────────────

@bp.route("/")
def index():
    return render_template("index.html")


@bp.route("/dashboard")
def dashboard():
    return render_template("dashboard.html", predictions=recent_predictions())


@bp.route("/patient-form")
def patient_form():
    return render_template("patient_form.html")


@bp.route("/live")
def live_monitor():
    return render_template("live_monitor.html")


# ── Prediction routes ────────────────────────────────────────────────────────

@bp.route("/predict", methods=["POST"])
def predict():
    form = request.form
    uploaded = request.files.get("csv_file")
    if not uploaded or not uploaded.filename:
        return render_template(
            "patient_form.html",
            error="Please upload an EEG CSV file.",
        ), 400
    if not uploaded.filename.lower().endswith(".csv"):
        return render_template(
            "patient_form.html",
            error="Please upload a file with the .csv extension.",
        ), 400

    try:
        result = get_predictor().predict_csv(uploaded)
    except Exception as exc:
        return render_template(
            "patient_form.html",
            error=f"Could not predict from this CSV: {exc}",
        ), 400

    patient_name = form.get("patient_name", "Unknown")
    age_raw = form.get("age")
    age = int(age_raw) if age_raw and age_raw.isdigit() else None
    try:
        save_prediction(patient_name, age, result)
    except Exception:
        # Prediction succeeded; a temporary storage fault must not kill the
        # request or make the user repeat a potentially expensive upload.
        current_app.logger.exception("Could not save prediction history")
    return render_template("result.html", result=result, patient_name=patient_name)


@bp.route("/api/predict", methods=["POST"])
def api_predict():
    uploaded = request.files.get("csv_file")
    if uploaded:
        try:
            return jsonify(get_predictor().predict_csv(uploaded))
        except Exception as exc:
            return jsonify({"error": str(exc)}), 400

    payload = request.get_json(force=True, silent=True) or {}
    values = payload.get("signals", payload)
    result = get_predictor().predict(values)
    return jsonify(result)


# ── Live-monitor API ─────────────────────────────────────────────────────────

@bp.route("/api/live/ports")
def api_live_ports():
    """Return a JSON list of available serial ports."""
    return jsonify(list_serial_ports())


@bp.route("/api/live/stream")
def api_live_stream():
    """
    Server-Sent Events stream of EEG channel data + disease prediction.

    Query params:
        port      COM port name, or omit / 'simulate' for simulated data
        baud      baud rate (default 115200)
    """
    port = request.args.get("port", None) or None
    baud = int(request.args.get("baud", 115200))

    try:
        predictor = get_predictor()
    except Exception as exc:
        # If no model is trained yet, fall through with None – stream will
        # emit channel data without prediction payloads.
        predictor = None

    def generate():
        try:
            for frame in live_eeg_stream(
                port=port,
                baud_rate=baud,
                predictor=predictor,
            ):
                data = json.dumps(frame, default=float)
                yield f"data: {data}\n\n"
        except GeneratorExit:
            pass
        except Exception as exc:
            yield f"data: {json.dumps({'error': str(exc)})}\n\n"

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",   # needed for Nginx proxies
        },
    )
