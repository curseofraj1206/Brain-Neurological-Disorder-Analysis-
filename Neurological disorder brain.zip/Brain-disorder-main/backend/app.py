from pathlib import Path

from flask import Flask
from flask_cors import CORS

from backend.database import init_db
from backend.routes import bp


PROJECT_ROOT = Path(__file__).resolve().parents[1]
def create_app():
    app = Flask(
        __name__,
        template_folder=str(PROJECT_ROOT / "frontend" / "templates"),
        static_folder=str(PROJECT_ROOT / "frontend" / "static"),
    )
    CORS(app, resources={r"/api/*": {"origins": "*"}})
    app.register_blueprint(bp)
    init_db()
    return app


app = create_app()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
