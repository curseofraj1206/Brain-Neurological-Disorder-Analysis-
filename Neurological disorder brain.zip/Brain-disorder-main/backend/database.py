import sqlite3
import json
import os
from datetime import datetime
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _default_db_path() -> Path:
    configured_dir = os.environ.get("BRAIN_SIGNAL_DB_DIR")
    if configured_dir:
        base = Path(configured_dir)
    else:
        base = PROJECT_ROOT / "instance"
    return base / "predictions.db"


DB_PATH = Path(os.environ.get("BRAIN_SIGNAL_DB", _default_db_path()))
JSONL_PATH = PROJECT_ROOT / "reports" / "prediction_reports" / "predictions.jsonl"
_USE_JSONL = False


def init_db():
    global _USE_JSONL
    if _USE_JSONL:
        JSONL_PATH.parent.mkdir(parents=True, exist_ok=True)
        return

    try:
        DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS predictions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    patient_name TEXT,
                    age INTEGER,
                    prediction TEXT NOT NULL,
                    confidence REAL NOT NULL,
                    scores TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                """
            )
    except (OSError, sqlite3.Error):
        _USE_JSONL = True
        JSONL_PATH.parent.mkdir(parents=True, exist_ok=True)


def save_prediction(patient_name: str, age: int | None, prediction: dict):
    global _USE_JSONL
    init_db()
    if _USE_JSONL:
        record = {
            "patient_name": patient_name,
            "age": age,
            "prediction": prediction["prediction"],
            "confidence": prediction["confidence"],
            "scores": prediction["scores"],
            "created_at": datetime.now().isoformat(timespec="seconds"),
        }
        with JSONL_PATH.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record) + "\n")
        return

    try:
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute(
                """
                INSERT INTO predictions (patient_name, age, prediction, confidence, scores)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    patient_name,
                    age,
                    prediction["prediction"],
                    prediction["confidence"],
                    str(prediction["scores"]),
                ),
            )
    except (OSError, sqlite3.Error):
        _USE_JSONL = True
        save_prediction(patient_name, age, prediction)


def recent_predictions(limit: int = 20):
    global _USE_JSONL
    init_db()
    if _USE_JSONL:
        if not JSONL_PATH.exists():
            return []
        rows = []
        with JSONL_PATH.open(encoding="utf-8") as handle:
            for line in handle:
                if line.strip():
                    rows.append(json.loads(line))
        return list(reversed(rows))[:limit]

    try:
        with sqlite3.connect(DB_PATH) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM predictions ORDER BY created_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [dict(row) for row in rows]
    except (OSError, sqlite3.Error):
        _USE_JSONL = True
        return recent_predictions(limit)
