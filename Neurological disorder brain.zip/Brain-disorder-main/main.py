import argparse

from realtime.prediction import BrainDisorderPredictor
from realtime.esp32_serial_bridge import read_esp32_serial
from training.evaluate import evaluate_saved_model
from training.train_ensemble import train_ensemble
from training.train_transformer import train_transformer
from training.train_xgboost import train_xgboost


def main():
    parser = argparse.ArgumentParser(description="Brain Signal AI")
    sub = parser.add_subparsers(dest="command")

    # ── train ─────────────────────────────────────────────────────────────────
    train = sub.add_parser("train", help="Train a model.")
    train.add_argument(
        "--model",
        choices=["all", "ensemble", "xgboost", "transformer"],
        default="xgboost",
        help="Which model to train (default: xgboost).",
    )
    train.add_argument(
        "--max-rows-per-file",
        type=int,
        default=None,
        help="Max rows to read per raw CSV file (default: all rows).",
    )
    train.add_argument(
        "--epochs",
        type=int,
        default=30,
        help="Max epochs for transformer training (early stopping may end it earlier).",
    )
    train.add_argument("--batch-size", type=int, default=128)

    # ── evaluate ──────────────────────────────────────────────────────────────
    sub.add_parser("evaluate", help="Evaluate the best saved model on the test set.")

    # ── serve ─────────────────────────────────────────────────────────────────
    serve = sub.add_parser("serve", help="Start the Flask web server.")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=5000)

    # ── predict (single sample) ───────────────────────────────────────────────
    predict = sub.add_parser("predict", help="Predict from channel values.")
    predict.add_argument("--model-file", default=None)
    for channel in [
        "Fp1", "Fp2", "F3", "F4", "C3", "C4", "P3", "P4", "O1", "O2",
        "F7", "F8", "T7", "T8", "P7", "P8", "Fz", "Cz", "Pz",
    ]:
        predict.add_argument(f"--{channel}", type=float, default=0.0)

    # ── predict-csv ───────────────────────────────────────────────────────────
    predict_csv = sub.add_parser("predict-csv", help="Predict from a CSV file.")
    predict_csv.add_argument("csv_path")
    predict_csv.add_argument(
        "--max-rows",
        type=int,
        default=None,
        help="Max rows to read from the CSV (default: all rows).",
    )
    predict_csv.add_argument("--model-file", default=None)

    # ── esp32-serial ──────────────────────────────────────────────────────────
    esp32_serial = sub.add_parser("esp32-serial", help="Read from ESP32 serial port.")
    esp32_serial.add_argument("--port", required=True, help="Serial port, e.g. COM5")
    esp32_serial.add_argument("--baud-rate", type=int, default=115200)
    esp32_serial.add_argument("--timeout-seconds", type=float, default=2.0)
    esp32_serial.add_argument(
        "--no-write-result",
        action="store_true",
        help="Do not send prediction JSON back to the ESP32 over serial.",
    )

    args = parser.parse_args()

    if args.command == "train":
        if args.model == "all":
            print("Training XGBoost, transformer, and ensemble on CPU...")
            print("xgboost:", train_xgboost(max_rows_per_file=args.max_rows_per_file))
            print("transformer:", train_transformer(max_rows_per_file=args.max_rows_per_file, epochs=args.epochs, batch_size=args.batch_size))
            print("ensemble:", train_ensemble(max_rows_per_file=args.max_rows_per_file))
        elif args.model == "ensemble":
            print(train_ensemble(max_rows_per_file=args.max_rows_per_file))
        elif args.model == "transformer":
            print(
                train_transformer(
                    max_rows_per_file=args.max_rows_per_file,
                    epochs=args.epochs,
                    batch_size=args.batch_size,
                )
            )
        else:
            # xgboost is the default
            print(train_xgboost(max_rows_per_file=args.max_rows_per_file))

    elif args.command == "evaluate":
        print(evaluate_saved_model())

    elif args.command == "serve":
        from backend.app import app
        app.run(host=args.host, port=args.port, debug=False)

    elif args.command == "predict":
        values = vars(args)
        values.pop("command", None)
        model_file = values.pop("model_file", None)
        print(BrainDisorderPredictor(model_file).predict(values))

    elif args.command == "predict-csv":
        with open(args.csv_path, "rb") as csv_file:
            print(
                BrainDisorderPredictor(args.model_file).predict_csv(
                    csv_file,
                    max_rows=args.max_rows,
                )
            )

    elif args.command == "esp32-serial":
        for result in read_esp32_serial(
            port=args.port,
            baud_rate=args.baud_rate,
            timeout_seconds=args.timeout_seconds,
            write_result=not args.no_write_result,
        ):
            print(result)

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
